package org.example.repository;

public class DataBaseConnectionConfig {
    public static String DB_URL="jdbc:postgresql://localhost:5432/movies";
    public static String DB_USER="postgres";
    public static String DB_Password="hello";
}

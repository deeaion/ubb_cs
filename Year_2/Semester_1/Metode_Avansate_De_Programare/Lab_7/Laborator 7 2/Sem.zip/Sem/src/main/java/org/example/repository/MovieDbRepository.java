package org.example.repository;

import org.example.domain.Movie;
import org.example.domain.User;

import java.sql.*;
import java.util.HashSet;
import java.util.Optional;

public class MovieDbRepository implements Repository<Long, Movie>{
    private String url,username,password;

    public MovieDbRepository(String url, String username, String password) {
        this.url = url;
        this.username = username;
        this.password = password;
    }

    @Override
    public Optional<Movie> findOne(Long aLong) {
        return Optional.empty();
    }

    @Override
    public Iterable<Movie> findAll() {
        HashSet<Movie> movies=new HashSet<>();
        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement statement = connection.prepareStatement("select * from movies");
             ResultSet resultSet = statement.executeQuery()
        ) {

            while (resultSet.next())
            {
                Long id= resultSet.getLong("id");
                String title=resultSet.getString("title");
                String director=resultSet.getString("director");
                int year=resultSet.getInt("year");
                Movie movie=new Movie(title,director,year);
                movie.setId(id);
                movies.add(movie);


            }
            return movies;

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public Optional<Movie> save(Movie entity) {
        return Optional.empty();
    }

    @Override
    public Optional<Movie> delete(Long aLong) {
        return Optional.empty();
    }

    @Override
    public Optional<Movie> update(Movie entity) {
        return Optional.empty();
    }
}
